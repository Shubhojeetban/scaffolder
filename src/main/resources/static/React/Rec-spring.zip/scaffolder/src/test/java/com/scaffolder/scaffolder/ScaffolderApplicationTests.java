package com.scaffolder.scaffolder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScaffolderApplicationTests {

	@Test
	void contextLoads() {
	}

}
