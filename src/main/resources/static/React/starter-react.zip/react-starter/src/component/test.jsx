import React, { Component } from 'react'

export class test extends Component {
    constructor(props) {
        super(props)

        this.state = {
            apiResponse: ""
        }
    }
    callAPI() {
        fetch("http://localhost:8000/api/hello-world")
            .then(res => res.text())
            .then(res => this.setState({ apiResponse: res }));
    }
    componentDidMount() {
        this.callAPI();
    }
  render() {
    return (
      <div>{this.state.apiResponse}</div>
    )
  }
}

export default test