
import './App.css';
import Test from './component/test';


import React from 'react'

function App() {
    return ( <
        Test / >
    )
}

export default App