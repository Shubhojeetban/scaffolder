const express = require("express")
const app = express()

const PORT = 8000
const cors = require("cors");
const routerAPI = require("./routes/testAPI")


app.use(express.json())
app.use(cors())
app.use(express.urlencoded({ extended: false }))
app.use("/api/hello-world", routerAPI);
app.listen(PORT, (req, res) => {
    console.log("Listening on port 8000");
})