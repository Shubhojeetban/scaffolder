package com.starter.starterspring.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.starter.starterspring.dto.Response;

@RestController
@RequestMapping("/api")
public class Controller {
	
	@GetMapping("/hello-world")
	public Response message() {
		Response response = new Response();
		response.setMessage("Hello World");
		return response;
	}
}
