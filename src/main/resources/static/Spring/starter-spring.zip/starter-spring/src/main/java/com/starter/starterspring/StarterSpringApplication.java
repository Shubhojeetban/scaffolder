package com.starter.starterspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StarterSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(StarterSpringApplication.class, args);
	}

}
