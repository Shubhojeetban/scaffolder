package com.starter.starterspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StarterSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
