import { Component } from '@angular/core';
import { ApiService } from './services/api.service';
import {environment} from "../environments/environment"
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'starter-angular';
  message!:any;
  constructor(private apiService:ApiService){

  }
  ngOnInit(): void {
    this.apiService.connectApi().subscribe({next:(res)=>{
          this.message=JSON.stringify(res);
          console.log(res);
      },
      error:()=>{
        this.message=`Requested url:${environment.apiUrl} is not found`;
      }
    }
    )
  }

}
